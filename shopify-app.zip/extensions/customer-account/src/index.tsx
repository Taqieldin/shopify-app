import React from 'react';

/**
 * Shopify Customer Account UI Extension
 * Target: customer-account.page.render
 * Renders the customer's private club status, owned pieces, and active privileges.
 */
export default function CustomerAccountExtension() {
  return (
    <div style={{ padding: '16px', fontFamily: 'inherit' }}>
      <div style={{ background: '#18181b', color: '#f4f4f5', borderRadius: '12px', padding: '20px' }}>
        <h2 style={{ fontSize: '1.2rem', margin: '0 0 8px 0' }}>Private Club & Collector Vault</h2>
        <p style={{ fontSize: '0.85rem', color: '#a1a1aa', margin: 0 }}>
          Manage your verified pieces, view digital product passports, and unlock bespoke atelier privileges.
        </p>
      </div>
    </div>
  );
}
