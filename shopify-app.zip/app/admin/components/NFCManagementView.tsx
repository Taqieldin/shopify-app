import { useState, useEffect } from 'react';
import {
  Page,
  Layout,
  Card,
  DataTable,
  Button,
  Modal,
  TextField,
  Banner,
  Badge,
  ButtonGroup,
  Thumbnail,
} from '@shopify/polaris';

interface NFCTaggedPiece {
  id: string;
  serial: string;
  nfc_uid: string;
  product_ref: {
    title: string;
    image_url?: string;
  };
  passport?: {
    status: string;
  };
}

export function NFCManagementView() {
  const [pieces, setPieces] = useState<NFCTaggedPiece[]>([]);
  const [loading, setLoading] = useState(false);
  const [modalActive, setModalActive] = useState(false);
  const [selectedPiece, setSelectedPiece] = useState<string | null>(null);
  const [nfcUid, setNfcUid] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  useEffect(() => {
    loadNFCPieces();
  }, []);

  const loadNFCPieces = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/admin/nfc');
      const data = await response.json();
      if (data.success) {
        setPieces(data.data);
      }
    } catch (err) {
      setError('Failed to load NFC-tagged pieces');
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterNFC = async () => {
    if (!selectedPiece || !nfcUid) return;

    setLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/admin/nfc/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          physical_piece_id: selectedPiece,
          nfc_uid: nfcUid,
        }),
      });

      const data = await response.json();
      if (data.success) {
        setSuccess('NFC tag registered successfully');
        setModalActive(false);
        setNfcUid('');
        setSelectedPiece(null);
        loadNFCPieces();
      } else {
        setError(data.error || 'Failed to register NFC tag');
      }
    } catch (err) {
      setError('Failed to register NFC tag');
    } finally {
      setLoading(false);
    }
  };

  const handleUnregisterNFC = async (pieceId: string) => {
    if (!confirm('Remove NFC tag from this piece?')) return;

    setLoading(true);
    try {
      const response = await fetch(`/api/admin/nfc/${pieceId}`, {
        method: 'DELETE',
      });

      const data = await response.json();
      if (data.success) {
        setSuccess('NFC tag removed');
        loadNFCPieces();
      }
    } catch (err) {
      setError('Failed to remove NFC tag');
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadQR = async (serial: string, format: 'png' | 'svg') => {
    try {
      const response = await fetch(`/api/admin/qr/${serial}/${format}`);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `qr-${serial}.${format}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      setError(`Failed to download QR code`);
    }
  };

  const handleDownloadLabel = async (serial: string) => {
    try {
      window.open(`/api/admin/labels/${serial}/download`, '_blank');
    } catch (err) {
      setError('Failed to open label');
    }
  };

  const rows = pieces.map((piece) => [
    <Thumbnail
      source={piece.product_ref.image_url || ''}
      alt={piece.product_ref.title}
      size="small"
    />,
    piece.serial,
    piece.product_ref.title,
    <code style={{ fontSize: '0.9em', background: '#f4f4f4', padding: '2px 6px', borderRadius: '3px' }}>
      {piece.nfc_uid}
    </code>,
    <Badge status={piece.passport?.status === 'ACTIVE' ? 'success' : 'attention'}>
      {piece.passport?.status || 'NO_PASSPORT'}
    </Badge>,
    <ButtonGroup>
      <Button size="slim" onClick={() => handleDownloadQR(piece.serial, 'png')}>
        QR PNG
      </Button>
      <Button size="slim" onClick={() => handleDownloadQR(piece.serial, 'svg')}>
        QR SVG
      </Button>
      <Button size="slim" onClick={() => handleDownloadLabel(piece.serial)}>
        Label
      </Button>
      <Button
        size="slim"
        destructive
        onClick={() => handleUnregisterNFC(piece.id)}
      >
        Remove NFC
      </Button>
    </ButtonGroup>,
  ]);

  return (
    <Page
      title="NFC Tag Management"
      primaryAction={{
        content: 'Register NFC Tag',
        onAction: () => setModalActive(true),
      }}
      secondaryActions={[
        {
          content: 'Bulk Register',
          onAction: () => {
            // TODO: Implement bulk upload modal
            alert('Bulk upload coming soon');
          },
        },
      ]}
    >
      <Layout>
        {error && (
          <Layout.Section>
            <Banner tone="critical" onDismiss={() => setError(null)}>
              {error}
            </Banner>
          </Layout.Section>
        )}

        {success && (
          <Layout.Section>
            <Banner tone="success" onDismiss={() => setSuccess(null)}>
              {success}
            </Banner>
          </Layout.Section>
        )}

        <Layout.Section>
          <Card>
            <DataTable
              columnContentTypes={['text', 'text', 'text', 'text', 'text', 'text']}
              headings={['Image', 'Serial', 'Product', 'NFC UID', 'Status', 'Actions']}
              rows={rows}
              loading={loading}
            />
          </Card>
        </Layout.Section>

        <Layout.Section>
          <Card title="About NFC Tags" sectioned>
            <p>
              NFC (Near Field Communication) tags allow customers to tap their smartphone
              against a product to instantly verify authenticity and view the digital passport.
            </p>
            <br />
            <p>
              <strong>Supported tags:</strong> NTAG424 DNA, NTAG213, NTAG215, NTAG216
            </p>
            <br />
            <p>
              <strong>Note:</strong> NFC UIDs should be paired with cryptographic verification
              for high-security applications.
            </p>
          </Card>
        </Layout.Section>
      </Layout>

      <Modal
        open={modalActive}
        onClose={() => setModalActive(false)}
        title="Register NFC Tag"
        primaryAction={{
          content: 'Register',
          onAction: handleRegisterNFC,
          loading,
        }}
        secondaryActions={[
          {
            content: 'Cancel',
            onAction: () => setModalActive(false),
          },
        ]}
      >
        <Modal.Section>
          <TextField
            label="Physical Piece ID"
            value={selectedPiece || ''}
            onChange={setSelectedPiece}
            placeholder="Enter piece UUID"
            autoComplete="off"
            helpText="The UUID of the physical piece to link the NFC tag to"
          />
          <br />
          <TextField
            label="NFC UID"
            value={nfcUid}
            onChange={setNfcUid}
            placeholder="04ABC123DEF456"
            autoComplete="off"
            helpText="The unique identifier from the NFC tag (hex format)"
          />
        </Modal.Section>
      </Modal>
    </Page>
  );
}
