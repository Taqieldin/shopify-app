import React, { createContext, useContext, useState, useEffect } from 'react';

export interface TenantData {
  id: string;
  shopify_shop_id: string;
  shop_domain: string;
  plan: string;
  settings: {
    brand_name: string;
    logo_url?: string;
    primary_color: string;
    secondary_color: string;
    accent_color: string;
    font_family: string;
    passport_term: string;
    club_name: string;
    credits_term: string;
    membership_terms: string[];
    public_story_enabled: boolean;
  };
  features: Record<string, boolean>;
}

export interface MockPiece {
  id: string;
  serial: string;
  product_title: string;
  product_handle: string;
  product_image: string;
  category: string;
  edition_number?: number;
  edition_total?: number;
  status: 'MANUFACTURED' | 'REGISTERED' | 'TRANSFERRED' | 'SERVICED' | 'RESTORED' | 'LOST' | 'STOLEN' | 'REVOKED';
  nfc_uid?: string;
  manufacturing_date: string;
  manufacturing_location: string;
  materials: Array<{ name: string; origin?: string; certification?: string }>;
  color: string;
  dimensions: string;
  active_owner?: {
    name: string;
    email: string;
    started_at: string;
  };
}

export interface MockPassport {
  id: string;
  piece_id: string;
  serial: string;
  title: string;
  description: string;
  hero_image: string;
  gallery: string[];
  craft_info: string;
  heritage_story: string;
  materials_summary: string;
  sustainability_data: string;
  view_count: number;
  status: 'ACTIVE' | 'DRAFT' | 'REVOKED';
}

export interface MockTransfer {
  id: string;
  serial: string;
  product_title: string;
  sender_email: string;
  recipient_email: string;
  recipient_name?: string;
  transfer_token: string;
  status: 'PENDING' | 'ACCEPTED' | 'COMPLETED' | 'CANCELLED' | 'EXPIRED';
  expires_at: string;
  certificate_number?: string;
  verification_hash?: string;
}

export interface MockAuthEvent {
  id: string;
  serial: string;
  method: 'NFC' | 'QR' | 'SERIAL';
  result: 'AUTHENTICATED' | 'UNREGISTERED' | 'SUSPICIOUS' | 'REVOKED';
  risk_level: 'NORMAL' | 'LOW_RISK' | 'REVIEW' | 'HIGH_RISK';
  country: string;
  city: string;
  nfc_counter?: number;
  timestamp: string;
}

export interface MockCreditEntry {
  id: string;
  customer_email: string;
  amount: number;
  type: 'EARN' | 'REDEEM' | 'BONUS' | 'ADJUSTMENT' | 'REVERSAL';
  reason: string;
  created_by: string;
  created_at: string;
}

export interface MockServiceCase {
  id: string;
  case_number: string;
  serial: string;
  service_type: string;
  status: 'RECEIVED' | 'IN_PROGRESS' | 'COMPLETED';
  technician_name: string;
  received_date: string;
  completed_date?: string;
  warranty_covered: boolean;
  cost_amount: number;
  internal_notes: string;
  customer_notes: string;
}

interface TenantContextType {
  currentTenant: TenantData;
  switchTenant: (tenantId: string) => void;
  availableTenants: TenantData[];
  pieces: MockPiece[];
  passports: MockPassport[];
  transfers: MockTransfer[];
  authEvents: MockAuthEvent[];
  creditEntries: MockCreditEntry[];
  serviceCases: MockServiceCase[];
  auditLogs: Array<{ id: string; action: string; actor: string; target: string; time: string; metadata?: any }>;
  // Actions
  createPieceAndPassport: (piece: Partial<MockPiece>, passport: Partial<MockPassport>) => void;
  initiateTransfer: (serial: string, recipientEmail: string, recipientName?: string) => string;
  acceptTransfer: (token: string, recipientEmail: string, recipientName: string) => { certNumber: string; hash: string };
  postCreditAdjustment: (customerEmail: string, amount: number, reason: string) => void;
  createServiceCase: (service: Partial<MockServiceCase>) => void;
  updateServiceStatus: (caseId: string, status: 'RECEIVED' | 'IN_PROGRESS' | 'COMPLETED', customerNotes?: string) => void;
  reportTheft: (serial: string, type: 'LOST' | 'STOLEN', notes?: string) => void;
  updateSettings: (settings: Partial<TenantData['settings']>) => void;
  updateFeatures: (features: Record<string, boolean>) => void;
  simulateAuthScan: (serial: string, method: 'NFC' | 'QR', country?: string) => MockAuthEvent;
}

const INITIAL_TENANTS: TenantData[] = [
  {
    id: 'tenant-1-aurelia',
    shopify_shop_id: 'gid://shopify/Shop/8492019482',
    shop_domain: 'maison-aurelia.myshopify.com',
    plan: 'PRO',
    settings: {
      brand_name: 'Maison Aurelia',
      logo_url: '',
      primary_color: '#1c1917',
      secondary_color: '#78716c',
      accent_color: '#c2410c',
      font_family: 'Playfair Display',
      passport_term: 'Certificat Numérique',
      club_name: 'Le Cercle Aurelia',
      credits_term: 'Points Privilège',
      membership_terms: ['Maison Collector', 'Atelier Privilège', 'Cercle d’Or'],
      public_story_enabled: true,
    },
    features: {
      digital_passport_enabled: true,
      authentication_enabled: true,
      nfc_enabled: true,
      qr_enabled: true,
      ownership_enabled: true,
      transfer_enabled: true,
      membership_enabled: true,
      credits_enabled: true,
      benefits_enabled: true,
      care_enabled: true,
      service_enabled: true,
      warranty_enabled: true,
      lost_stolen_enabled: true,
      analytics_enabled: true,
    },
  },
  {
    id: 'tenant-2-vanguard',
    shopify_shop_id: 'gid://shopify/Shop/9918273645',
    shop_domain: 'vanguard-horology.myshopify.com',
    plan: 'ENTERPRISE',
    settings: {
      brand_name: 'Vanguard Horology',
      logo_url: '',
      primary_color: '#0f172a',
      secondary_color: '#64748b',
      accent_color: '#0284c7',
      font_family: 'Cinzel',
      passport_term: 'Horological Passport',
      club_name: "The Collector's Guild",
      credits_term: 'Guild Credits',
      membership_terms: ['Apprentice', 'Guild Master', 'Grand Horologist'],
      public_story_enabled: true,
    },
    features: {
      digital_passport_enabled: true,
      authentication_enabled: true,
      nfc_enabled: true,
      qr_enabled: true,
      ownership_enabled: true,
      transfer_enabled: true,
      membership_enabled: true,
      credits_enabled: true,
      benefits_enabled: true,
      care_enabled: true,
      service_enabled: true,
      warranty_enabled: true,
      lost_stolen_enabled: true,
      analytics_enabled: true,
    },
  },
];

const INITIAL_PIECES: MockPiece[] = [
  {
    id: 'pc-1',
    serial: 'AUR-2026-000184',
    product_title: 'The Étoile Flap Top-Handle Bag in Box Calfskin',
    product_handle: 'etoile-flap-top-handle-bag',
    product_image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1000&q=80',
    category: 'Handbags & Leather',
    edition_number: 18,
    edition_total: 100,
    status: 'REGISTERED',
    nfc_uid: '04:7A:B2:99:41:2F:80',
    manufacturing_date: '2026-02-14',
    manufacturing_location: 'Atelier Aurelia, Florence, Italy',
    materials: [
      { name: 'Full-Grain Box Calf Leather', origin: 'Tuscany, Italy', certification: 'LWG Gold Rated' },
      { name: '24k Gold-Plated Brass Hardware', origin: 'Arezzo, Italy', certification: 'Precious Alloy' },
      { name: 'Pure Silk Jacquard Lining', origin: 'Lyon, France' },
    ],
    color: 'Noir Intense with Gold Hardware',
    dimensions: '28 cm x 18 cm x 9 cm',
    active_owner: {
      name: 'Claire Delacroix',
      email: 'claire.delacroix@example.com',
      started_at: '2026-03-01',
    },
  },
  {
    id: 'pc-2',
    serial: 'AUR-2026-000185',
    product_title: 'The Étoile Flap Top-Handle Bag in Box Calfskin',
    product_handle: 'etoile-flap-top-handle-bag',
    product_image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=1000&q=80',
    category: 'Handbags & Leather',
    edition_number: 19,
    edition_total: 100,
    status: 'MANUFACTURED',
    nfc_uid: '04:7A:B2:99:41:2F:81',
    manufacturing_date: '2026-02-15',
    manufacturing_location: 'Atelier Aurelia, Florence, Italy',
    materials: [
      { name: 'Full-Grain Box Calf Leather', origin: 'Tuscany, Italy' },
      { name: 'Palladium Hardware', origin: 'Arezzo, Italy' },
    ],
    color: 'Cognac Saddle with Palladium',
    dimensions: '28 cm x 18 cm x 9 cm',
  },
  {
    id: 'pc-3',
    serial: 'VNG-2026-000042',
    product_title: 'Astralis Tourbillon Monopusher Chronograph 41mm',
    product_handle: 'astralis-tourbillon-monopusher',
    product_image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=1000&q=80',
    category: 'Haute Horlogerie',
    edition_number: 4,
    edition_total: 25,
    status: 'REGISTERED',
    nfc_uid: '04:E1:88:22:90:3A:99',
    manufacturing_date: '2026-01-20',
    manufacturing_location: 'Manufacture Vanguard, Geneva, Switzerland',
    materials: [
      { name: 'Grade 5 Titanium & 950 Platinum', origin: 'Switzerland' },
      { name: 'Anti-Reflective Double Sapphire Crystal', origin: 'Switzerland' },
      { name: 'Hand-Stitched Alligator Leather Strap', origin: 'Geneva' },
    ],
    color: 'Midnight Blue Guilloché Dial',
    dimensions: '41.5mm Diameter x 12.8mm Thickness',
    active_owner: {
      name: 'Marcus Vance',
      email: 'marcus.vance@example.com',
      started_at: '2026-02-01',
    },
  },
];

const INITIAL_PASSPORTS: MockPassport[] = [
  {
    id: 'pass-1',
    piece_id: 'pc-1',
    serial: 'AUR-2026-000184',
    title: 'Digital Passport — Étoile Edition No. 18',
    description: 'Hand-stitched using 140 meters of waxed linen thread and saddle-finished over 42 hours by Master Artisan Matteo Rossi.',
    hero_image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1000&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=1000&q=80',
    ],
    craft_info: 'Traditional double-needle saddle stitch technique, hand-painted edge dyes applied in 7 consecutive coats, individual number engraved on inner brass plate.',
    heritage_story: 'Rooted in 1920s Parisian luggage-making traditions, the Étoile silhouette balances geometric restraint with soft curves.',
    materials_summary: 'Grade A Tuscan Calfskin treated with natural vegetable tanning agents, aging with a lustrous caramel patina.',
    sustainability_data: '100% Traceable European Raw Hides, Zero Waste Offcut Recycling Protocol, Lifetime Restoration Guarantee.',
    view_count: 342,
    status: 'ACTIVE',
  },
  {
    id: 'pass-3',
    piece_id: 'pc-3',
    serial: 'VNG-2026-000042',
    title: 'Digital Passport — Astralis Tourbillon No. 04/25',
    description: 'Manufacture Calibre VG-8800 with 72-hour power reserve, single-axis flying tourbillon, and column-wheel chronograph mechanism.',
    hero_image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=1000&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=1000&q=80',
    ],
    craft_info: 'Côtes de Genève hand-finishing, anglaged bridge beveling polished with gentian wood, blued titanium screws.',
    heritage_story: 'Conceived in the Vallée de Joux, the Astralis series reimagines astronomical complications with contemporary material science.',
    materials_summary: 'Grade 5 Titanium & 950 Platinum with double anti-reflective sapphire crystal.',
    sustainability_data: 'COSC Certified Chronometer, Ethical Gold Association Standard, 50-Year Movement Service Warranty.',
    view_count: 512,
    status: 'ACTIVE',
  },
];

const INITIAL_TRANSFERS: MockTransfer[] = [
  {
    id: 'trf-101',
    serial: 'AUR-2026-000184',
    product_title: 'The Étoile Flap Top-Handle Bag in Box Calfskin',
    sender_email: 'claire.delacroix@example.com',
    recipient_email: 'sophie.laurent@example.com',
    recipient_name: 'Sophie Laurent',
    transfer_token: 'TRF_9f81a7b6c5d4e3f201928374',
    status: 'PENDING',
    expires_at: '2026-08-20T23:59:59Z',
  },
];

const INITIAL_AUTH_EVENTS: MockAuthEvent[] = [
  {
    id: 'ev-1',
    serial: 'AUR-2026-000184',
    method: 'NFC',
    result: 'AUTHENTICATED',
    risk_level: 'NORMAL',
    country: 'France',
    city: 'Paris',
    nfc_counter: 14,
    timestamp: 'Just now',
  },
  {
    id: 'ev-2',
    serial: 'AUR-2026-000184',
    method: 'QR',
    result: 'AUTHENTICATED',
    risk_level: 'NORMAL',
    country: 'France',
    city: 'Paris',
    timestamp: '2 hours ago',
  },
  {
    id: 'ev-3',
    serial: 'VNG-2026-000042',
    method: 'NFC',
    result: 'AUTHENTICATED',
    risk_level: 'NORMAL',
    country: 'Switzerland',
    city: 'Geneva',
    nfc_counter: 9,
    timestamp: '5 hours ago',
  },
];

const INITIAL_CREDITS: MockCreditEntry[] = [
  {
    id: 'crd-1',
    customer_email: 'claire.delacroix@example.com',
    amount: 500,
    type: 'EARN',
    reason: 'Acquisition of Étoile No. 18',
    created_by: 'ORDER:ORD-99120',
    created_at: '2026-03-01',
  },
  {
    id: 'crd-2',
    customer_email: 'claire.delacroix@example.com',
    amount: 100,
    type: 'BONUS',
    reason: 'Digital Passport Registration Milestone',
    created_by: 'SYSTEM',
    created_at: '2026-03-01',
  },
];

const INITIAL_SERVICES: MockServiceCase[] = [
  {
    id: 'srv-1',
    case_number: 'SRV-89412-AURELIA',
    serial: 'AUR-2026-000184',
    service_type: 'Annual Leather Spa & Edge Seal Nourishment',
    status: 'COMPLETED',
    technician_name: 'Matteo Rossi',
    received_date: '2026-05-10',
    completed_date: '2026-05-14',
    warranty_covered: true,
    cost_amount: 0,
    internal_notes: 'Flap corner edge seal touched up with 2 coats of black resin.',
    customer_notes: 'Atelier leather care completed with natural organic beeswax treatment.',
  },
];

const TenantContext = createContext<TenantContextType | undefined>(undefined);

export const TenantProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentTenantId, setCurrentTenantId] = useState('tenant-1-aurelia');
  const [tenants, setTenants] = useState(INITIAL_TENANTS);
  const [pieces, setPieces] = useState(INITIAL_PIECES);
  const [passports, setPassports] = useState(INITIAL_PASSPORTS);
  const [transfers, setTransfers] = useState(INITIAL_TRANSFERS);
  const [authEvents, setAuthEvents] = useState(INITIAL_AUTH_EVENTS);
  const [creditEntries, setCreditEntries] = useState(INITIAL_CREDITS);
  const [serviceCases, setServiceCases] = useState(INITIAL_SERVICES);
  const [auditLogs, setAuditLogs] = useState<
    Array<{ id: string; action: string; actor: string; target: string; time: string; metadata?: any }>
  >([
    {
      id: 'aud-1',
      action: 'SYSTEM_BOOTSTRAPPED',
      actor: 'system',
      target: 'TENANT',
      time: '2026-08-16 22:30',
      metadata: { status: 'INITIALIZED' },
    },
  ]);

  const currentTenant = tenants.find((t) => t.id === currentTenantId) || tenants[0];

  // Filter pieces and data relevant to current tenant prefix or tenant domain
  const isAurelia = currentTenant.id === 'tenant-1-aurelia';
  const tenantPieces = pieces.filter((p) => (isAurelia ? p.serial.startsWith('AUR') : p.serial.startsWith('VNG')));
  const tenantPassports = passports.filter((p) => (isAurelia ? p.serial.startsWith('AUR') : p.serial.startsWith('VNG')));

  const switchTenant = (tenantId: string) => {
    setCurrentTenantId(tenantId);
  };

  const createPieceAndPassport = (pieceData: Partial<MockPiece>, passportData: Partial<MockPassport>) => {
    const newPieceId = `pc-${Date.now()}`;
    const serial = pieceData.serial || `${isAurelia ? 'AUR' : 'VNG'}-2026-${Math.floor(100000 + Math.random() * 900000)}`;

    const newPiece: MockPiece = {
      id: newPieceId,
      serial,
      product_title: pieceData.product_title || 'Haute Creation',
      product_handle: pieceData.product_handle || 'haute-creation',
      product_image: pieceData.product_image || 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1000&q=80',
      category: pieceData.category || 'Luxury Goods',
      edition_number: pieceData.edition_number || 1,
      edition_total: pieceData.edition_total || 50,
      status: 'MANUFACTURED',
      nfc_uid: `04:${Math.random().toString(16).slice(2, 4).toUpperCase()}:${Math.random().toString(16).slice(2, 4).toUpperCase()}`,
      manufacturing_date: new Date().toISOString().split('T')[0],
      manufacturing_location: isAurelia ? 'Atelier Florence, Italy' : 'Manufacture Geneva, Switzerland',
      materials: pieceData.materials || [{ name: 'Precious Materials' }],
      color: pieceData.color || 'Signature Tone',
      dimensions: pieceData.dimensions || 'Standard Bespoke',
    };

    const newPassport: MockPassport = {
      id: `pass-${Date.now()}`,
      piece_id: newPieceId,
      serial,
      title: passportData.title || `Digital Passport — ${newPiece.product_title}`,
      description: passportData.description || 'Certified authentic luxury piece.',
      hero_image: newPiece.product_image,
      gallery: [newPiece.product_image],
      craft_info: passportData.craft_info || 'Handcrafted by master artisans.',
      heritage_story: passportData.heritage_story || 'Maison heritage and craftsmanship.',
      materials_summary: passportData.materials_summary || 'Finest certified materials.',
      sustainability_data: passportData.sustainability_data || '100% Traceable European Materials.',
      view_count: 1,
      status: 'ACTIVE',
    };

    setPieces((prev) => [newPiece, ...prev]);
    setPassports((prev) => [newPassport, ...prev]);

    setAuditLogs((prev) => [
      {
        id: `aud-${Date.now()}`,
        action: 'PASSPORT_CREATED',
        actor: 'merchant_admin',
        target: serial,
        time: new Date().toLocaleTimeString(),
        metadata: { title: newPassport.title },
      },
      ...prev,
    ]);
  };

  const initiateTransfer = (serial: string, recipientEmail: string, recipientName?: string) => {
    const token = `TRF_${Math.random().toString(36).substring(2)}${Math.random().toString(36).substring(2)}`;
    const piece = pieces.find((p) => p.serial === serial);

    const newTransfer: MockTransfer = {
      id: `trf-${Date.now()}`,
      serial,
      product_title: piece?.product_title || 'Luxury Piece',
      sender_email: piece?.active_owner?.email || 'owner@example.com',
      recipient_email: recipientEmail,
      recipient_name: recipientName,
      transfer_token: token,
      status: 'PENDING',
      expires_at: new Date(Date.now() + 72 * 3600 * 1000).toISOString(),
    };

    setTransfers((prev) => [newTransfer, ...prev]);

    setAuditLogs((prev) => [
      {
        id: `aud-${Date.now()}`,
        action: 'OWNERSHIP_TRANSFER_INITIATED',
        actor: 'customer',
        target: serial,
        time: new Date().toLocaleTimeString(),
        metadata: { recipient_email: recipientEmail, token },
      },
      ...prev,
    ]);

    return token;
  };

  const acceptTransfer = (token: string, recipientEmail: string, recipientName: string) => {
    const transfer = transfers.find((t) => t.transfer_token === token);
    const certNumber = `CERT-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
    const hash = `0x${Math.random().toString(16).substring(2)}${Math.random().toString(16).substring(2)}`;

    if (transfer) {
      setTransfers((prev) =>
        prev.map((t) =>
          t.transfer_token === token
            ? { ...t, status: 'COMPLETED', certificate_number: certNumber, verification_hash: hash }
            : t
        )
      );

      setPieces((prev) =>
        prev.map((p) =>
          p.serial === transfer.serial
            ? {
                ...p,
                status: 'TRANSFERRED',
                active_owner: {
                  name: recipientName,
                  email: recipientEmail,
                  started_at: new Date().toISOString().split('T')[0],
                },
              }
            : p
        )
      );
    }

    setAuditLogs((prev) => [
      {
        id: `aud-${Date.now()}`,
        action: 'OWNERSHIP_TRANSFER_COMPLETED',
        actor: 'customer',
        target: transfer?.serial || 'UNKNOWN',
        time: new Date().toLocaleTimeString(),
        metadata: { recipient_email: recipientEmail, certNumber },
      },
      ...prev,
    ]);

    return { certNumber, hash };
  };

  const postCreditAdjustment = (customerEmail: string, amount: number, reason: string) => {
    const entry: MockCreditEntry = {
      id: `crd-${Date.now()}`,
      customer_email: customerEmail,
      amount,
      type: amount >= 0 ? 'ADJUSTMENT' : 'REDEEM',
      reason,
      created_by: 'ADMIN:staff_01',
      created_at: new Date().toISOString().split('T')[0],
    };

    setCreditEntries((prev) => [entry, ...prev]);

    setAuditLogs((prev) => [
      {
        id: `aud-${Date.now()}`,
        action: amount >= 0 ? 'CREDITS_GRANTED' : 'CREDITS_DEBITED',
        actor: 'merchant_admin',
        target: customerEmail,
        time: new Date().toLocaleTimeString(),
        metadata: { amount, reason },
      },
      ...prev,
    ]);
  };

  const createServiceCase = (serviceData: Partial<MockServiceCase>) => {
    const caseNumber = `SRV-${Math.floor(10000 + Math.random() * 90000)}-${isAurelia ? 'AUR' : 'VNG'}`;
    const newCase: MockServiceCase = {
      id: `srv-${Date.now()}`,
      case_number: caseNumber,
      serial: serviceData.serial || tenantPieces[0]?.serial || 'AUR-2026-000184',
      service_type: serviceData.service_type || 'Restoration & Leather Nourishment',
      status: 'RECEIVED',
      technician_name: serviceData.technician_name || 'Master Artisan',
      received_date: new Date().toISOString().split('T')[0],
      warranty_covered: serviceData.warranty_covered ?? true,
      cost_amount: serviceData.cost_amount || 0,
      internal_notes: serviceData.internal_notes || 'Atelier receipt inspection.',
      customer_notes: serviceData.customer_notes || 'Your piece has arrived at our atelier.',
    };

    setServiceCases((prev) => [newCase, ...prev]);

    setAuditLogs((prev) => [
      {
        id: `aud-${Date.now()}`,
        action: 'SERVICE_CASE_CREATED',
        actor: 'merchant_admin',
        target: newCase.serial,
        time: new Date().toLocaleTimeString(),
        metadata: { case_number: caseNumber },
      },
      ...prev,
    ]);
  };

  const updateServiceStatus = (caseId: string, status: 'RECEIVED' | 'IN_PROGRESS' | 'COMPLETED', customerNotes?: string) => {
    setServiceCases((prev) =>
      prev.map((s) =>
        s.id === caseId
          ? {
              ...s,
              status,
              completed_date: status === 'COMPLETED' ? new Date().toISOString().split('T')[0] : s.completed_date,
              customer_notes: customerNotes || s.customer_notes,
            }
          : s
      )
    );
  };

  const reportTheft = (serial: string, type: 'LOST' | 'STOLEN', notes?: string) => {
    setPieces((prev) =>
      prev.map((p) => (p.serial === serial ? { ...p, status: type === 'STOLEN' ? 'STOLEN' : 'LOST' } : p))
    );

    setAuditLogs((prev) => [
      {
        id: `aud-${Date.now()}`,
        action: type === 'STOLEN' ? 'PRODUCT_MARKED_STOLEN' : 'PRODUCT_MARKED_LOST',
        actor: 'merchant_admin',
        target: serial,
        time: new Date().toLocaleTimeString(),
        metadata: { notes },
      },
      ...prev,
    ]);
  };

  const updateSettings = (newSettings: Partial<TenantData['settings']>) => {
    setTenants((prev) =>
      prev.map((t) =>
        t.id === currentTenant.id
          ? { ...t, settings: { ...t.settings, ...newSettings } }
          : t
      )
    );
  };

  const updateFeatures = (newFeatures: Record<string, boolean>) => {
    setTenants((prev) =>
      prev.map((t) =>
        t.id === currentTenant.id
          ? { ...t, features: { ...t.features, ...newFeatures } }
          : t
      )
    );
  };

  const simulateAuthScan = (serial: string, method: 'NFC' | 'QR', country = 'France'): MockAuthEvent => {
    const piece = pieces.find((p) => p.serial === serial);
    const isStolen = piece?.status === 'STOLEN' || piece?.status === 'LOST';

    const event: MockAuthEvent = {
      id: `ev-${Date.now()}`,
      serial,
      method,
      result: isStolen ? 'SUSPICIOUS' : piece?.status === 'REGISTERED' ? 'AUTHENTICATED' : 'UNREGISTERED',
      risk_level: isStolen ? 'HIGH_RISK' : 'NORMAL',
      country,
      city: country === 'France' ? 'Paris' : country === 'Switzerland' ? 'Geneva' : 'Tokyo',
      nfc_counter: method === 'NFC' ? Math.floor(Math.random() * 50) + 1 : undefined,
      timestamp: 'Just now',
    };

    setAuthEvents((prev) => [event, ...prev]);

    return event;
  };

  return (
    <TenantContext.Provider
      value={{
        currentTenant,
        switchTenant,
        availableTenants: tenants,
        pieces: tenantPieces,
        passports: tenantPassports,
        transfers,
        authEvents,
        creditEntries,
        serviceCases,
        auditLogs,
        createPieceAndPassport,
        initiateTransfer,
        acceptTransfer,
        postCreditAdjustment,
        createServiceCase,
        updateServiceStatus,
        reportTheft,
        updateSettings,
        updateFeatures,
        simulateAuthScan,
      }}
    >
      {children}
    </TenantContext.Provider>
  );
};

export const useTenant = () => {
  const context = useContext(TenantContext);
  if (!context) {
    throw new Error('useTenant must be used within a TenantProvider');
  }
  return context;
};
