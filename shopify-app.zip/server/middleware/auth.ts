import { Response, NextFunction } from 'express';
import { ForbiddenError, UnauthorizedError } from '../shared/errors/index.js';
import { TenantRequest } from './tenant.js';
import { UserRole } from '../shared/types/index.js';

export interface AuthenticatedRequest extends TenantRequest {
  userRole?: UserRole;
  actorId?: string;
}

export function requireRole(...allowedRoles: UserRole[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    // In local dev/demo mode, default to MERCHANT_ADMIN for admin routes
    const role: UserRole = (req.headers['x-user-role'] as UserRole) || 'MERCHANT_ADMIN';
    const actorId = (req.headers['x-actor-id'] as string) || 'merchant_admin_01';

    req.userRole = role;
    req.actorId = actorId;

    if (allowedRoles.length > 0 && !allowedRoles.includes(role)) {
      return next(new ForbiddenError(`Operation requires one of roles: ${allowedRoles.join(', ')}`));
    }

    next();
  };
}
