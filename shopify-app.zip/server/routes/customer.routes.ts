import { Router, Response, NextFunction } from 'express';
import { OwnershipService } from '../domains/ownership/ownership.service.js';
import { MembershipService } from '../domains/membership/membership.service.js';
import { CreditsService } from '../domains/credits/credits.service.js';
import { BenefitsService } from '../domains/benefits/benefits.service.js';
import { TransferService } from '../domains/transfer/transfer.service.js';
import { tenantMiddleware, TenantRequest } from '../middleware/tenant.js';

export const customerRouter = Router();

customerRouter.use(tenantMiddleware);

// Middleware extracting authenticated customer
function extractCustomer(req: TenantRequest, res: Response, next: NextFunction) {
  const customerId =
    (req.headers['x-shopify-customer-id'] as string) ||
    'gid://shopify/Customer/7182930192'; // Claire Delacroix default in dev

  (req as any).customerId = customerId;
  next();
}

customerRouter.use(extractCustomer);

/**
 * GET /api/customer/me/collection
 * Fetch customer's owned pieces (Collector's Cabinet)
 */
customerRouter.get('/me/collection', async (req: TenantRequest, res: Response, next: NextFunction) => {
  try {
    const shopId = req.tenant!.shop_id;
    const customerId = (req as any).customerId;
    const collection = await OwnershipService.getCustomerCollection(shopId, customerId);
    res.json({ success: true, data: collection });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/customer/me/membership
 * Fetch customer membership level and tiers
 */
customerRouter.get('/me/membership', async (req: TenantRequest, res: Response, next: NextFunction) => {
  try {
    const shopId = req.tenant!.shop_id;
    const customerId = (req as any).customerId;
    const membership = await MembershipService.getCustomerMembership(shopId, customerId);
    res.json({ success: true, data: membership });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/customer/me/credits
 * Fetch customer credits statement and running balance
 */
customerRouter.get('/me/credits', async (req: TenantRequest, res: Response, next: NextFunction) => {
  try {
    const shopId = req.tenant!.shop_id;
    const customerId = (req as any).customerId;
    const statement = await CreditsService.getStatement(shopId, customerId);
    res.json({ success: true, data: statement });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/customer/me/transfer
 * Initiate piece ownership transfer
 */
customerRouter.post('/me/transfer', async (req: TenantRequest, res: Response, next: NextFunction) => {
  try {
    const shopId = req.tenant!.shop_id;
    const customerId = (req as any).customerId;
    const transfer = await TransferService.initiateTransfer(shopId, {
      serial: req.body.serial,
      sender_shopify_customer_id: customerId,
      recipient_email: req.body.recipient_email,
      recipient_name: req.body.recipient_name,
    });
    res.json({ success: true, data: transfer });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/customer/me/benefits/:id/claim
 * Claim private club perk
 */
customerRouter.post('/me/benefits/:id/claim', async (req: TenantRequest, res: Response, next: NextFunction) => {
  try {
    const shopId = req.tenant!.shop_id;
    const customerId = (req as any).customerId;
    const claim = await BenefitsService.redeemBenefit(shopId, req.params.id as string, customerId);
    res.json({ success: true, data: claim });
  } catch (err) {
    next(err);
  }
});
