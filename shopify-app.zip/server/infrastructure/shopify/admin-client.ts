import { prisma } from '../database/client.js';

export interface ShopifyGraphQLResponse<T = any> {
  data?: T;
  errors?: Array<{ message: string; locations?: any[] }>;
}

export class ShopifyAdminClient {
  private shopDomain: string;
  private accessToken: string;
  private apiVersion: string;

  constructor(shopDomain: string, accessToken = 'mock_token', apiVersion = '2026-01') {
    this.shopDomain = shopDomain;
    this.accessToken = accessToken;
    this.apiVersion = apiVersion;
  }

  /**
   * Execute authenticated GraphQL Admin query against Shopify
   */
  async graphql<T = any>(query: string, variables: Record<string, any> = {}): Promise<T> {
    // In mock/offline dev, simulate Shopify Admin response if not connected to live store
    if (this.accessToken === 'mock_token' || process.env.NODE_ENV === 'development') {
      return this.simulateGraphQLResponse<T>(query, variables);
    }

    const response = await fetch(
      `https://${this.shopDomain}/admin/api/${this.apiVersion}/graphql.json`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Shopify-Access-Token': this.accessToken,
        },
        body: JSON.stringify({ query, variables }),
      }
    );

    const json = (await response.json()) as ShopifyGraphQLResponse<T>;
    if (json.errors && json.errors.length > 0) {
      throw new Error(`Shopify GraphQL Error: ${json.errors[0].message}`);
    }

    return json.data as T;
  }

  /**
   * Mock simulation for testing without live Shopify credentials
   */
  private simulateGraphQLResponse<T>(query: string, variables: any): T {
    if (query.includes('products(')) {
      return {
        products: {
          edges: [
            {
              node: {
                id: 'gid://shopify/Product/98412049182',
                title: 'The Étoile Flap Top-Handle Bag in Box Calfskin',
                handle: 'etoile-flap-top-handle-bag',
                images: {
                  edges: [{ node: { url: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3' } }],
                },
              },
            },
          ],
        },
      } as any;
    }

    return {} as T;
  }
}
